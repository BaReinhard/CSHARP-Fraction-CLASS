﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fraction_Class_Example_Console_Program
{
    class Program
    {
        static void Main(string[] args)
        {
            string strOverLoad = "Overloaded operator ";
            Fraction overload = new Fraction();
            string fracFirst;
            string fracSecond;
            decimal decFirst;
            int decPlaces;
            Console.Write("Please choose your first fraction: ");
            fracFirst = Console.ReadLine();
            Console.Write("Please choose your second fraction: ");
            fracSecond = Console.ReadLine();
            Console.Write("Please choose your decimal to convert: ");
            decFirst = Convert.ToDecimal(Console.ReadLine());
            Console.Write("Please choose how many decimal places you want to use for your decimal. i.e dec= 0.2311 dec places = 3 shows: 231/1000 then reduces: ");
            decPlaces = Convert.ToInt16(Console.ReadLine());
            overload.DecToFrac(decFirst, decPlaces, true);
            Console.Write(decFirst + " to a proper fraction = ");
            Console.WriteLine(overload.ReturnFraction());
            overload.DecToFrac(decFirst, decPlaces, false);
            Console.Write(decFirst + " to an improper fraction = ");
            Console.WriteLine(overload.ReturnFraction());
            Fraction addFrac = new Fraction(fracFirst);
            Fraction multFrac = new Fraction(fracSecond);
            Console.Write(strOverLoad + "* : " + fracFirst + " * " + fracSecond + " = ");
            overload = addFrac * multFrac;
            Console.WriteLine(overload.ReturnFraction());
            Console.Write(strOverLoad + "/ : " + fracFirst + " / " + fracSecond + " = ");
            overload = addFrac / multFrac;
            Console.WriteLine(overload.ReturnFraction());
            Console.Write(strOverLoad + "+ : " + fracFirst + " + " + fracSecond + " = ");
            overload = addFrac + multFrac;
            Console.WriteLine(overload.ReturnFraction());
            Console.Write(strOverLoad + "- : " + fracFirst + " - " + fracSecond + " = ");
            overload = addFrac - multFrac;
            Console.WriteLine(overload.ReturnFraction());
            Console.Write(strOverLoad + "== : " + fracFirst + " == " + fracSecond + " = ");
            Console.WriteLine(addFrac == multFrac);
            Console.Write(strOverLoad + ">= : " + fracFirst + " >= " + fracSecond + " = ");
            Console.WriteLine(addFrac >= multFrac);
            Console.Write(strOverLoad + "<= : " + fracFirst + " <= " + fracSecond + " = ");
            Console.WriteLine(addFrac <= multFrac);
            Console.Write(strOverLoad + "> : " + fracFirst + " > " + fracSecond + " = ");
            Console.WriteLine(addFrac > multFrac);
            Console.Write(strOverLoad + "< : " + fracFirst + " < " + fracSecond + " = ");
            Console.WriteLine(addFrac < multFrac);

            Console.ReadLine();
        }
    }
}
